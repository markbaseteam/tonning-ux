#research 

## Types of research

There are two ways to categorize research: _who conducts_ the research and the _type of data_ collected.

The first way to categorize research is based on who conducts the research: primary research and secondary research.

**Primary research** is research _you_ conduct yourself. Information from direct interactions with users, like interviews, surveys, or usability studies, are considered primary research.

**Secondary research** is research that uses information _someone else_ has put together. For example, using information from sources like books, articles, or journals is considered secondary research.

The second way to categorize research is based on the type of data collected: qualitative or quantitative.

**Qualitative research** is primarily collected _through observations and conversations_. Qualitative research is based on understanding users’ needs and aims to answer questions like “why” or “how did this happen?”

**Quantitative research** focuses on data that can be _gathered by counting or measuring_. Quantitative research is based on numerical data that’s often collected from large-scale surveys. This type of research aims to answer questions like “how many?” and “how much?”

![[Types of research.png]]


## Primary research methods

Now that you understand the different types of research, let’s review some common primary research methods for gathering information.

### Interviews

**Interviews** are a research method used to collect in-depth information on people's opinions, thoughts, experiences, and feelings. Interviews can be performed one-on-one or in a group setting, like a focus group. 

Interviews can take the form of qualitative and quantitative research. A qualitative research method includes open-ended questions that require participants to explain their answers by providing more details. A quantitative research method includes only close-ended questions, like questions that require only “yes”  or “no” responses or set multiple choice questions.

Best practice is to conduct at least five user interviews during your research. As you conduct your interviews, you’ll start to find similarities in the feedback that users provide about what works and what doesn’t work about your product. This is exactly the kind of feedback you want! 

#### Advantages

-   You’re better able to understand what a user thinks and why.
-   You can adjust your questions or refocus the discussion based on the user’s answers.
-   You have the ability to ask follow-up questions in real time.
-   You have the ability to ask questions specific to a user’s needs.
-   You’ll receive direct suggestions from the user. 

#### Disadvantages

-   It’s time-consuming to interview each user. 
-   It’s expensive to pay participants and to rent space for the interviews.
-   The sample sizes are smaller, due to time and money constraints.
-   Group interviews can be affected by the bandwagon effect, or going along with the group’s opinion instead of thinking creatively, which can discourage open discussion by people who have an opinion that doesn’t align with the majority of the group. 

If you want to learn more about interviews, check out [an article about user interviews](https://www.nngroup.com/articles/user-interviews/#:~:text=Topics%3A,of%20learning%20about%20that%20topic.) from the Nielsen Norman Group.


### Surveys

A **survey** is an activity where many people are asked the same questions in order to understand what most people think about a product. Surveys are a great way to measure the success of your product, during development and after it’s launched. For example, sending surveys after a product is released can help you measure the effectiveness of your product and provide a foundation for future improvements. 

You can design surveys to include open-ended questions for qualitative research, which allow research participants to clarify their survey responses, as well as close-ended questions for quantitative research, which generate numerical data.

#### Advantages

-   You can learn more from a larger sample size.
-   You are able to gather results and insights quickly. 
-   Surveys are usually inexpensive because they don’t take as much time for participants to complete, and they can be done remotely. 

#### Disadvantages

-   Surveys often do not allow for in-depth feedback; most questions will have responses drawn from a set of multiple-choice answers. 
-   There are some types of research questions that won’t work in a survey format.
-   Surveys usually do not allow for personalization.

If you want to learn more about surveys, check out usability.gov's [article about online surveys](https://www.usability.gov/how-to-and-tools/methods/online-surveys.html). 


### Usability survey

A **usability study** is a technique used to evaluate a product by testing it on users. Usability studies help demonstrate if a product is on the right track or if the design needs to be adjusted. There are lots of ways to test usability, both in person and online. It’s a good idea to record your usability sessions, either audio or video, so you can reference the user data as you make design decisions later on in the process. 

Qualitative research is based on observations, and a critical part of conducting usability studies is observing how participants interact with the product you’ve designed. Focusing on qualitative research during usability studies can generate more personal insights by assessing the behavior of users as they experience the product. Quantitative research can also be used when conducting usability studies to understand participants’ impressions of the product.

#### Advantages 

-   You can learn from first-hand user interaction and observation. 
-   Usability studies can challenge your assumptions about your product by demonstrating a completely different result than you were expecting. 
-   Users can provide in-depth feedback. 

#### Disadvantages

-   Usability studies only measures how easy it is to use a product.
-   This type of research can be expensive, especially if it’s conducted in person. 
-   There can be differences between a “controlled” usability study in a lab versus how a user experiences the product in their real life. 

If you want to learn more about usability tests, check out the Nielsen Norman Group's [article on usability testing](https://www.nngroup.com/articles/usability-testing-101/).


## Secondary research methods

Secondary research can be completed at any phase of the project, since you’re using information from outside sources. In other words, secondary research is not a direct result of your product or the user you’re designing for. The information you discover during secondary research might lay a foundation for your primary research, so you have a better idea of where to focus your efforts. Or, secondary research might supplement the findings from your primary research for a project, to reiterate or strengthen your conclusions.

### Advantages

-   Secondary research is generally cheaper and faster than primary research. This means you’ll save time and money. 
-   You can often find secondary research via online searches and subscription research publications.
-   Secondary research can be a good supplement to findings from your primary research.

### Disadvantages

-   You will not learn from any first-hand user interaction.
-   You will not receive user feedback specific to your product.
-   Secondary research can be misleading and generalizing if not done appropriately. 

If you want to learn more about secondary research, check out [an article about secondary research](https://www.formpl.us/blog/secondary-research) from Formplus.