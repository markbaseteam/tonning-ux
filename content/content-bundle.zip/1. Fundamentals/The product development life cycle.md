1. Brainstorm
2. Define
3. Design
4. Test
5. Launch