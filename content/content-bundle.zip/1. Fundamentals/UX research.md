#research
## Two key parts to every UX design project
* Conducting research to learn about the users you’re designing for.
* Gathering feedback about their perspectives.

![[UX research.png]]

## Foundational research
**Foundational research** is always done _before_ you start designing. Within the product development life cycle, foundational research happens during the brainstorm stage (stage one) to help you empathize with users, understand their needs, and inspire new design directions. During this stage, you will also make personas and user stories, which you'll learn about soon.

In foundational research, your goal is to figure out what the user needs and how to address those needs with your product. Strong foundational research can contradict your personal perspective on what a good solution might be. 

Questions you might consider during foundational research include:

-   What should we build?
-   What are the user’s problems?
-   How can we solve those problems?
-   Am I aware of my own biases, and am I able to filter them as I do research?

There are lots of research methods for conducting foundational research, but many of them are based on observations. Common foundational research methods include: 

-   **Interviews:** A research method used to collect in-depth information on people's opinions, thoughts, experiences, and feelings. You’ll often conduct interviews of your target users themselves.
-   **Surveys:** An activity where many people are asked the same questions in order to understand what most people think about a product.
-   **Focus groups:** A small group of people whose reactions are studied. For example, your focus group might bring together eight users to discuss their perspectives about new features in your design. A focus group is usually run by a moderator who guides the group on a certain topic of conversation. 
-   **Competitive audit:** An overview of your competitors’ strengths and weaknesses. You'll conduct your own competitive audit later in the course, so you will understand this research method well! 
-   **Field studies:** Research activities that take place in the user's context or personal environment, rather than in an office or lab. 
-   **Diary studies:** A research method used to collect qualitative data about user behaviors, activities, and experiences over time. Often, a user will log, or diary, about their daily activities and provide information about their behaviors and needs, which can help inform your designs.


## Design research
**Design research** is done _while_ you design. Within the product development lifecycle, design research happens during the design stage (stage three) to help inform your designs, to fit the needs of users, and to reduce risk. Each time you create a new version of your design, new research should be done to evaluate what works well and what needs to be changed. 

In design research, your goal is to answer the question: How should we build it?

The amount of design research you conduct will vary depending on where you work and what you’re building. The most common method used to conduct design research is a **usability study**, which is a technique to evaluate a product by testing it on users. The goal of usability studies is to identify pain points that the user experiences with your prototypes, so the issues can be fixed before the product launches. You’ll conduct your own usability study in the next course of this certificate program. 

Additional research methods that might be used to conduct design research include:

-   **A/B testing**: A research method that evaluates and compares two different aspects of a product to discover which of them is most effective. For example, you might have users evaluate two layouts for the homepage of your app to find out which layout is more effective. 
-   **Cafe or guerrilla studies:** A research method where user feedback is gathered by taking a design or prototype into the public domain and asking passersby for their thoughts. For example, you might sit in a local coffee shop and ask customers if they would be willing to test your app design for a couple of minutes and provide feedback. 
-   **Card sorting:** A research method that instructs study participants to sort individual labels written on notecards into categories that make sense to them. This type of research is largely used to figure out the information architecture of your project, which we’ll discuss in the next course of the program — Course 3: Build Wireframes and Low-Fidelity Designs.
-   **Intercepts:** A research method that gathers on-site feedback from users as they engage in the activities being researched. Intercepts are often conducted in the field, so this type of research is often considered a subset of field research. An intercept study can provide quick, high-level feedback.


## Post launch research
**Post-launch research** is done _after_ the design is complete and your product has launched. Within the product development life cycle, post-launch research happens after the launch stage (stage five) to help validate that the product is meeting user needs through established metrics.

In post-launch research, your goal is to answer the question: Did we succeed? This research will tell you how your final product is performing based on established metrics, such as adoption, usage, user satisfaction, and more. 

You should use research methods that give insight into what the user thinks of your product and if their experience using your product aligns with how you intended it to function. Research methods you might use to conduct post-launch research include:

-   **A/B testing**
-   **Usability studies**
-   **Surveys**
-   **Logs analysis:** A research method used to evaluate recordings of users while they interact with your design, tools, etc.