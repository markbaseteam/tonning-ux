## Interaction designer
Focus on designing the experience of a product and how it functions. Strives to understand user flow - the path users take to do a task on an app, website or other platform.

## Visual designer
Focus on how the product looks. Often responsible for designing logos, illustrations, and icons, as well as font color, size and placement.

## Motion designer
Focus on what it feels like for a user to move through a product, and how to create smooth transitions. May also create animations and visual effects.

## VR/AR designer
Focus on products with immersive experiences, and how to leverage 3D space.

## UX researcher
Conducts studies or interviews that examine how people use a product. Often identifies pain point and explore how a product can help solve them.

## UX writer
Focus on the language within a product, and how to make it clearer for a more intuitive user experience. Work often includes writing labels for buttons, and determining the tone of language used in a product.

## UX program manager
Ensures clear and timely communication between design team, so the process of building a product moves smoothly from start to finish. This might include setting goals, writing project plans, and allocating team resources.

## UX engineer
Translates the design's intent into a functioning user experience. Helps UX teams determine if the designs are intuitive and technically feasible.

## Conversation designer
