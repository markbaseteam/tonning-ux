Presentations are a great way to share your research insights with people in your organization and external parties. There are many digital tools you can use to create a presentation, like Google Slides, Microsoft PowerPoint, and Apple Keynote. But regardless of the tool you use, how can you make sure that your presentations are strong enough to hold your audience’s attention and get your point across? In this reading, you’ll learn some tips for creating UX research presentations that keep your audience engaged from the first slide to the last!

## Tip 1: Know your audience

![Presenter speaking to the audience for their presentation.](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/EwBB5pFgTAiAQeaRYGwIVw_cbab410202c448418a7b871a6f462abf_UX_C4M4L1R2part1_A.png?expiry=1675468800000&hmac=yOJLF1PmSPA_Xjo8zy3vRfpIVflFnszZbqbhY8ZVRdM)

Before the presentation begins, take time to find out what the people you're presenting to are interested in learning about, then tailor your presentation accordingly. For example, a presentation to a marketing team will probably be different than a presentation to management, so you'll need to be adaptable. A personalized approach keeps your audience engaged during your presentation and increases your ability to gain their support for your project.

## Tip 2: Provide an overview

![Presenter showcasing a slide that says "Table of contents" to the audience](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/A05v-iUfTeWOb_olH-3luA_27fe979b283442709ffe90942be7ffa2_UX_C4M4L1R2part1_B.png?expiry=1675468800000&hmac=1vhbKl1HFOwUxmibl48uCL_mXTmnlbBr3BZTklBxbCQ)

Presenter showcasing a slide that says "Table of contents" to the audience. The Table of Contents reads: Section 1 - Study Details, Section 2 - Themes, Section 3 - Insights and Recommendation, and an appendix

Include a short roadmap or "table of contents" at the beginning of your presentation, so your audience knows what to expect throughout the presentation. Your roadmap should almost be like a checklist that the audience can follow along, so they have a vision for how much content is left to cover.

In addition, one slide should feature an overview of the content you’re presenting, also known as an executive summary. It’s kind of like sharing your conclusion or biggest takeaways at the beginning of the presentation. Be sure to discuss how your research impacts the big picture, like how the product would support the company’s goals and objectives. When your audience understands the overall goal of the presentation and your product from the start, they’ll have a better context for specific details and stories you provide later.

## Tip 3: Tell a story

![Presenter showcasing a slide that says "User: David" to the audience.](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/4P_W5NsnR4u_1uTbJyeL8w_b6a7447813ce480b85802829f17402a6_UX_C4M4L1R2part1_C.png?expiry=1675468800000&hmac=7nrM3JVUPNLiss0omuEGJBakRrb7JXGohM3macbYBrI)

Presenter showcasing a slide that says "User: David" to the audience. There's an image of the user and a speech bubble that shows their feedback.

Think of your presentation as a story with a beginning, middle, and end. Each slide should push the story you’re telling forward, and the story should flow from slide to slide. Part of telling an effective and engaging story is including examples of actual users, such as quotes, photos, or short video clips from interactions with users. Storytelling is more powerful than sharing a list of research insights because your audience can observe the emotions, pain points, and delights of your product from a real user’s point of view.

## Tip 4: Show numbers

![Presenter showcasing a slide that says shows a chart to the audience](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/tBdtWYCQRdiXbVmAkLXYug_4791c62b22154144aeb094e03746516b_UX_C4M4L1R2part1_D.png?expiry=1675468800000&hmac=P47bhf54j2tZ3qZjHBSEFhQH5FgVddw-t0Ia1_DZmiw)

A strong image often communicates more clearly than words. Use data, graphs, and charts to illustrate your most important insights. Your goal is to keep the attention of your audience, so let the images and data you show speak to your audience and strengthen the story you’re telling.

## Tip 5: Less is more when it comes to text

![Presenter showcasing a user persona to the audience](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/pJBgngXQSkCQYJ4F0HpA8Q_ee8e4aa92da54c98bd282e1002fb9e66_UX_C4M4L1R2part2_C.png?expiry=1675468800000&hmac=XOs6vh3XWnpcazIB5B31CLlG5korJwEBF38ujdAdlwI)

Keep the information you present short and to the point. Your slides should only include high-level details that answer questions like why, what, and how. Try to include minimal text on your slides so that the audience doesn't spend time reading while you're presenting. If necessary, you can add additional resources in the appendix of your presentation for the audience to review later.

## Tip 6: Provide recommendations for next steps

![Presenter showcasing a slide that says "Recommendations" to the audience](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/13Ymrx1GTE22Jq8dRvxN7g_70849798427b442fbe44240e47df1442_UX_C4M4L1R2part2_A.png?expiry=1675468800000&hmac=Vbu5CRJA6L_lckvZu2hB89DK2XPJ0CNpbmH3SvuNgdw)

Presenter showcasing a slide that says "Recommendations" to the audience Recommendations listed read Recommendation 1, Recommendation 2, Recommendation 3

End the presentation with a list of recommended next steps based on the insights you presented. Your recommendations might include changes to make to the product designs, additional research to conduct, or future meetings to schedule. This step helps gain support from stakeholders and will put the pieces in place to move forward in the design process. It's a best practice to clearly state your recommendations on a single slide.

## Tip 7: Leave time for questions

![Presenter showcasing a slide that says "Questions" to the audience](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/9NsltyEtRvSbJbchLTb00A_b7faa7e4fb74458c933b3ec690d06a18_UX_C4M4L1R2part2_B.png?expiry=1675468800000&hmac=6aY_Tfn4_VK5BPZZ7Qm2SiUc8Y14LKR55kYVorjkSYE)

At the end of your presentation, be sure to leave a few minutes so your audience can ask questions about the material you presented and can clarify any points. This is also a great opportunity for you to provide more details about areas that your audience is interested in learning more about.