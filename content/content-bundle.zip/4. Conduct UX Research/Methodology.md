**Methodology** involves the steps you’ll take to conduct research, collect data, and analyze data. When thinking about the methodology, it’s important to consider 1) the type of research method involved, 2) the steps involved in the research method, and 3) the type of data that will be generated from the research method.

## Comparing research methods

You learned in the first week of Course 2 about various primary and secondary research methods: **Primary research** is research _you_ conduct yourself, while **secondary research** is research that uses information _someone else_ has put together. Some examples of primary research are interviews—which you conducted in Course 2—surveys, [competitive audits](https://www.coursera.org/learn/start-ux-design-process/supplement/sFvs0/learn-more-about-competitive-audits), and usability studies. Another point to consider is whether the research method is _quantitative or qualitative_. **Qualitative research** focuses observations on why and how things happen, and **quantitative research** focuses on data that can be gathered by counting or measuring. 

For example, most of your primary, qualitative research will most likely be conducted during the **empathize** phase of the project, when your goal is to find out as much as possible about the challenges, needs and characteristics of potential users before creating designs.

Each method is unique and yields very different kinds of results. For more information, check out the [Learn more about research methods](https://www.coursera.org/learn/start-ux-design-process/supplement/4VPat/learn-more-about-research-methods) reading from Course 2.

## Conducting research with a usability study

For the purposes of Course 4, your research plan will include a **usability study** as the research method. In the last course, you learned how to create low-fidelity prototypes. This research method is ideal at this stage of a project because it involves testing out your design with real, potential users. 

Usability studies are _primary, qualitative_ research methods because they allow UX designers to make direct and indirect observations based on the participants’ behavior and words. You’ll give each participant a few guided tasks and take notes on how successfully the tasks are completed (direct observation), and you’ll also record the study in order to play it back later (indirect observation)to discover new insights from the study.