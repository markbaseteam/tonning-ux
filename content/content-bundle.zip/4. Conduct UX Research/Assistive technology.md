As you prepare to conduct your own research, you’ll need to be sure to include participants with varying abilities in order to get a range of feedback about your designs and to ensure that your designs are equitable. As a reminder, **accessibility** means the design of products, devices, services, or environments for people with disabilities. One of your key priorities as a UX designer is to create products that are usable and accessible to all people.

Sometimes, the abbreviation **a11y** (pronounced “A eleven Y”) is used to refer to accessibility. It’s shorthand for representing the 11 letters between the letter “a” and the letter “y” in the word “accessibility.” More importantly, a11y resembles the word “ally,” which reflects the idea that UX designers need to be allies to people with all types of abilities. 

It’s critical that you consider and involve people with various accessibility needs when designing, especially during the empathize and test phases of the design process.

## Accessibility is for everyone

If you make the design of a product easier for people with disabilities, you also often make it a better experience for everyone else. Designing for accessibility isn’t an obstacle, but a way to get your products to as many users as possible. In other words, designing for accessibility benefits everyone! 

As a UX designer, you need to design for people with disabilities that are permanent, temporary, or situational.

![Graphic showing permanent, temporary, and situational impairments](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/0tdf_mo2RVyXX_5qNnVctQ_7789582a569940029ff3d14ba62fac6e_Screenshot-2021-03-07-at-7.14.12-PM.png?expiry=1674864000000&hmac=gZYTpCtHD8LzRcwqGUWxKnfwpqrUge4SFrMiGNWAoLo)

A **permanent disability** is one that affects a person long-term, like losing sight, hearing, speech, or mobility. For example, Amir, a person with permanent blindness, uses a walking stick to navigate their surroundings. 

A **temporary impairment** is a short-term illness or ailment that can be caused by an injury or other limitation. Consider Margo, who has temporarily blurred vision without their glasses. 

A **situational challenge** occurs when a person’s environment blocks certain functions. For example, Juan cannot read text messages on their mobile phone while driving a car. Instead, Juan uses voice commands to hear and send texts while driving. 

You need to keep in mind users with a diverse range of abilities as you design features and products. You should also consider the types of assistive technology that people will use when experiencing your designs. An **assistive technology (AT)** is a product, equipment, or a system that enhances learning, working, and living for people with disabilities. In the examples above, assistive technologies came in the form of a walking stick, glasses, and voice commands. For your research study, you should strive to include as many different users of assistive technology as you can. 

![Assistive Technology image including: Reminder alarm, closed captioning, Switch, AAC, and screen reader](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/I_pUdIzUTg-6VHSM1B4Paw_bba39b63e575495ba4990a1cba5222d4_Screenshot-2021-03-07-at-7.11.08-PM.png?expiry=1674864000000&hmac=xxazD7fDTQNM2Q66lptf8jVbN3UxzvI-HEy6XcE2wfM)

Let’s explore some of the most common ATs.

-   A **screen reader** is an AT that interprets and verbalizes text, button names, keyboard strokes, and code that a website or app is composed of. Screen readers are often used by people with low vision. In addition to screen readers, some people with low vision might use a computer or smart device with a high contrast screen or increased magnification. 
    
-   A **switch** is an AT that helps people with disabilities use technology - like computers, phones, appliances, and mobility equipment - with minimal movements and gestures. A switch can come in many forms, like a button or clicker. For a computer, a switch might replace a traditional keyboard and mouse. 
    
-   **Closed captioning and speech-to-text** are both ATs that convert audio into text for people with limited hearing. 
    
-   **Reminder alarms** with simplified text and supporting images can help people with cognitive disabilities remember important information. For example, Android phones have a feature called [Action Blocks](https://support.google.com/accessibility/android/answer/9711267?hl=en) where users add common actions to their home screen with a name or image. So a photo of your mother on the home screen of your phone will call her phone number. 
    
-   **Augmentative and Alternative Communication (AAC) devices** are ATs that support people with cognitive disabilities who may experience speech limitations or learning disabilities by using images to communicate instead of words.