As a UX designer, you’ll regularly communicate and collaborate with others, especially while doing research. One of the most essential aspects of conducting research is understanding how to communicate effectively with all different kinds of people. In this reading, you’ll explore the distinct roles that language and communication play in UX research. 

![](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/N-ugyzWMROmroMs1jDTpeA_32d9487e134a489fb4e38fab4a5e77f1_Screenshot-2021-06-17-1.58.33-PM.png?expiry=1674864000000&hmac=xxrX4PN_J4VihOvdV5nP1KG2LE6ltv6Xy4CH1Hgy7wc)

## Language and communication matter

When it comes to UX research, written and spoken language play a very important role in the success of your product and the feedback you receive about your designs. Language is the primary tool you’ll use for collecting data, building relationships with research study participants, reporting research findings to your team, and representing the users you’re designing for.  

The language _you_ use while conducting research directly affects the language your _participants_ use. For example, if you use a formal speaking style, participants might feel less comfortable being open and honest, and they might respond in a more formal style themselves. Using language that’s appropriate for the context can help you get a deeper understanding of participants’ unique perspectives and values. Every word you use when asking questions, taking notes, or transcribing quotes needs to accurately represent the ideas that participants convey. 

Your understanding of the best language to use in any given situation will continually shift as you learn the ins and outs of conducting UX research. Using appropriate language while conducting research is an ongoing process!

## Consider word choices 

When conducting research, it’s important that you understand your own ideas on language use, as well as the ideas other communities have about language. This way, you can better identify and avoid your own biases about language use. All languages are important and complex, and they deserve to be represented equally. 

Keep in mind that some languages and language varieties express the same concepts in different ways. For example, in Standard American English, _potato chips_ are a popular savory snack, while in British English, the same snack is known as _crisps_. Similarly, African American English, Creole, and other dialects have their own unique words, pronunciations, and expressions. If you’re not certain what a research study participant meant by something they said, ask them! If that’s not possible, talk to colleagues or outside experts to learn about what the participant might have intended. As the UX designer conducting research, it’s your responsibility to seek clarification on language differences and to ensure the translations of participants’ insights are accurate. 

There’s no right or wrong way to communicate an idea, but language often reveals hidden power imbalances. When conducting research, you want to make sure you’re communicating in a way that’s inviting, not commanding. For example, avoid using words that are considered **ableist**, or words that assume a person does not have a disability. You can imagine that a researcher might say to a participant, “Let’s walk through the details of the study.” Instead, it’s just as easy to say, “Let’s go through the details of the study.” That second phrase doesn’t make any assumptions, intended or not, about a person’s physical capabilities. 

Overall, your goal when conducting research is to make participants feel welcomed and valued for who they are. It takes time to change language and word choice habits, so don’t get discouraged if you make a mistake. Being aware of the words you use is an important step in being inclusive.

## Keep the context in mind

You also need to consider the context that the research is happening in, such as the physical space where the research study is taking place. You want participants to feel like there’s an equal power dynamic between them and you as the researcher. For example, if one person is sitting and the other person is standing, there’s an unequal power dynamic and the situation can feel awkward or off putting. 

Some portions of your research studies might need to be adjusted to meet participants where they are. Different communities have different ways of interacting with others in various situations, so it’s important to be aware of those cultural differences. For example, some cultural groups take turns when speaking, while others feel free to interrupt whenever they have a great idea. In other words, one research study participant might consider interrupting to be rude, while another might think that interrupting shows engagement in the conversation. In your role as a researcher, you need to be aware of context changes and pay close attention to how participants prefer to communicate to create an equitable environment for all participants.