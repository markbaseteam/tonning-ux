Have you ever encountered a product or app and thought, “I have to have this!”? That’s not a coincidence! This is the dream for UX designers because we want to create products that provide a clear value for users. 

So, how can you use everything you’ve built so far — empathy maps, personas, user stories, problem statements, and hypothesis statements — to make users think, “I have to have this!”? 

Start by defining your product’s value propositions. **Value propositions** summarize why a consumer should use a product or service.


## Value proposition example

Check out a product you might recognize - Gmail – and ask yourself if you can identify a few of its value propositions. When Google debuted Gmail in 2004, they were entering an already crowded market of free email services. Gmail offered: 

-   The ability to send and receive emails for free
-   Email sorting, archiving, and starring functions
-   Spam filtering for inboxes
-   Email conversation views
-   1 gigabyte of cloud storage

Two of the items on that list were unique offerings that no other email services provided at the time: email conversation views, which put individual emails in the context of a larger thread, and an entire gigabyte of storage, which was 1,000 times the amount of storage that competitors offered. Those were Gmail’s unique value propositions. 

## Build value propositions

Everything that your product has to offer might seem obvious to you, but you have to put yourself in the mind of your users. Users don’t know your product or understand its value yet. That’s where value propositions come in. 

To start, you need to do some research in order to answer these two questions:

-   **What does your product do?** Clearly explain the offering that your product provides users. 
-   **Why should the user care?** Describe how your product addresses users’ pain points.

Once you’ve answered these questions, you can follow a series of steps to focus in on your product’s unique value proposition. Let’s use the dog walker app as an example to explore how this works in action.

**Step 1. Describe your product’s features and benefits.** Create a list of all the great features and benefits of your product, big and small. Don’t hold back; list everything that comes to mind and then narrow it down later.

![[Features.png]]

**Step 2. Explain the value of the product.** Anything that you identify as a value proposition needs to be beneficial to your users. In this example, for the dog walker app, there were four categories of product values that were identified during user interviews: accessible, professional experience of the dog walkers, cost, and reliability. The giant list of features and benefits from step one is sorted into those four categories.

![[Features categorized.png]]

There were a few features and benefits from the original list that didn't fit into these four categories and didn't add real “value” for the users: 

-   Monthly organic goodies and new products for your pets
-   Exclusively for dog walking (no other kinds of pets)
-   Rating system for walkers
-   Training tips

These features and benefits were not sorted into the four categories and were instead set to the side.

**Step 3. Connect these features and benefits with the needs of your users.** The goal is to identify what’s truly valuable to the user and not just a cool feature that users didn’t ask for. To determine value, take the personas you’ve developed and pair each persona with a value proposition that meets their biggest pain point.

![[Features connected.png]]

**Step 4. Review your official value proposition list.** You’ve narrowed your list down of lots of benefits and features by matching them with actual user needs. Now it’s time to review the list of value propositions your product offers. For the dog walker app, here are the value propositions that matched with the personas that were developed earlier:

-   Thorough training for walkers
-   Upgrade dog walkers to dog nanny for set, scheduled walks
-   Geo-tracking of walkers 
-   Calendar booking
-   Late-notice cancellation fees
-   Convenient lockers that hold your house keys 
-   Easy-to-use app design 

And there you have it, your list of value propositions! However, some of these features and benefits are also offered by your competitors. So how do you know what makes your product stand out from the competition? Identify your app’s unique value proposition. This means reviewing the list of value propositions that match to your personas and removing those that your competition also offers.

One way to check out your product’s competitors is to read reviews. Sort the reviews from lowest to highest, and closely examine what reviewers are sharing about your competition. Here are some reviews about a competitor dog walking app:

![[Competitor reviews.png]]

Can you identify the biggest pain point in this example? A common theme in some of the reviews is the need for thorough, in-person training for the dog walkers, to ensure that the dog walkers know how to do their jobs well. Some of the reviews also call out the need for dog walkers to be reliable. No other dog walking app is meeting this need, so that’s the unique value proposition our app can provide!


## Key takeaways

One of the most important things to know about value propositions is that they need to be short, clear, and to the point. Users want to be able to easily identify exactly how your product will meet their unique needs and what sets your product apart in the market. Sometimes users won’t know what they need until you explain it to them. That’s the real heart of product design innovation.