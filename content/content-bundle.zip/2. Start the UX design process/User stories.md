A **user story** is a fictional one-sentence story told from the persona’s point of view to inspire and inform design decisions. This is a great opportunity to use your imagination as you create the stories that capture the needs of your users.

User stories should be written in the following format:

![[User story.png]]

A template of a statement framing the WHO, WHAT, and WHY: As a type of user (WHO), I want to action (WHAT), so that benefit (WHY).

As a **type of user** (who), I want to **action** (what) so that **benefit** (why).

Using this format is a clear way to ensure your user story is communicating everything you need to know about the persona. The user stories you create will be very valuable as you start designing your product. User stories can also serve as a “checklist” to make sure you’re addressing and solving the key problems your users might face when engaging with your product. 

The best practice for user stories is to keep them short, impactful, and to the point, with a clear action and benefit.