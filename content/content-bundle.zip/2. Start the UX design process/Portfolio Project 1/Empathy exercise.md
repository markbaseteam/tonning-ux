#research 
## Zareen
Age: 22
Education: 4th year university student
Hometown: Bruges, Belgium
Family: 2 sisters
Occupation: Project management intern for a large international firm

Zareen is about to complete a B.A. in Business Administration and hopes an internship will launch her career in project management. Even though Zareen most enjoys the time spent working with her mentor on a campaign, she also enjoys doing other tasks like getting coffee and food for the office. She feels these tasks are a good opportunity to network and to demonstrate being a team player with keen attention to detail. 
Zareen would like to demonstrate her commitment on the job, complete everyday tasks efficiently, and eventually be trusted with increased responsibilities in the office. 

### Questions
* How often do you book movie theater seats?
	* About once a week, I love movies so when an opportunity arises I take advantage. Otherwise I'm busy with my new job.
* How do you prefer to book movie theater seats?
	* I use the movie theater's booking service, mostly on the web.
* What is the best and worst part about booking movie theater seats online?
	* Best part: Easy to select which seats we want.
	* Worst part: Each theater uses their own booking service, forcing me to create a new account for each one. Some also require that I download their app. I don't want a bunch of apps that do the same thing.
* If you could change one thing about the service you used for your most recent seat-booking experience, what would it be?
	* I would make it easier to see which seats are taken early in the payment process.
* What information would you expect in an app for booking seats at a movie theater?
	* Which seats are available, information about video & audio, movie information, price.
* Which medium do you prefer to use when booking movie theater seats, and why?
	* My phone, but in many cases I have to switch over to a PC because the booking websites are terrible on small screens. I prefer the phone because it's always on me.


## Joseph
Age: 20
Education: Enrolled in online college classes
Hometown: Nairobi, Kenya
Family: Lives with their mother, father and one younger sibling
Occupation: Full time student

Joseph is a recent immigrant to the United States who is enrolled in online college classes and is also taking classes at a night school for learning English. He can read English well, but sometimes encounters difficulties at restaurants or while out running errands, where shopkeepers tend to speak very quickly and limited translation options are available. Joseph is passionate about sports and the outdoors, and wants to explore what his neighborhood has to offer. 

Joseph’s priority is balancing his studies with fun, while also having time to look after his younger sibling when his parents are at work.

### Questions
* How often do you book movie theater seats?
	* A couple times a month. My younger brother loves movies, and I try to take him when there's an exciting movie out.
* How do you prefer to book movie theater seats?
	* On the theater's website. I don't understand verbal english very well yet, and when using the computer I can use a translator to understand better.
* What is the best and worst part about booking movie theater seats online?
	* Best part: I get to pick which seats I want.
	* Worst part: None of the theaters we go to have built in translation. which means I have to manually copy text over to a translator to understand fully.
* If you could change one thing about the service you used for your most recent seat-booking experience, what would it be?
	* I would like more language options.
* What information would you expect in an app for booking seats at a movie theater?
	* Price of tickets, seat availability, movie information and language/subtitle information.
* Which medium do you prefer to use when booking movie theater seats, and why?
	* I use my computer, but I would use my phone if I didn't have to manually translate the websites.

## Elliot
Age: 44
Education: Culinary school graduate
Hometown: Omaha, Nebraska
Family: Lives with partner
Occupation: Cook

Elliot is a line cook who lives in a small city and mostly works in the evenings. During the daytime, Elliot does an online data analytics bootcamp for 3-4 hours to learn a new employable skill. He usually does the bootcamp from local coffee shops or co-working spaces since his partner works from home and is in meetings all day. The bootcamp is expensive, so Elliot is trying to save money on food and transportation. 

Elliot’s priority is balancing work and studies with quality time spent on his hobbies and with loved ones.

### Questions
* How often do you book movie theater seats?
	* About once a month. We only really go to the theater if there's a new movie we've been waiting for. Otherwise we just use Netflix.
* How do you prefer to book movie theater seats?
	* Sometimes on the way from work I'll stop by the theater and buy tickets in the kiosk. But, most of the time I order online.
* What is the best and worst part about booking movie theater seats online?
	* Best part: It saves me time. I'm usually the one booking.
	* Worst part: Some of the theaters we go to have very confusing booking websites. I just want to be able to pick seats and pay.
* If you could change one thing about the service you used for your most recent seat-booking experience, what would it be?
	* I don't like having to give my contact information just to book tickets. Email is fine, but why do you need my phone?
* What information would you expect in an app for booking seats at a movie theater?
	* Which seats are available, and how much they cost.
* Which medium do you prefer to use when booking movie theater seats, and why?
	* Computer and in-person. Computer because it's quicker, in-person because it's easier.


## Neelam
Age: 35
Education: Master’s degree in Education
Hometown: Champagne, Illinois
Family: Married with one young child
Occupation: Teacher

Neelam is an established education professional with 10 years of teaching experience. She is passionate about her job but sometimes has trouble managing the stress of teaching while also raising a young child. Neelam also prepares breakfast and dinner for the family on most days, sometimes leaving her with little time to grade papers and plan syllabi. 

Neelam appreciates products that help her stay more organized and manage her time in the classroom and at home.

### Questions
* How often do you book movie theater seats?
	* Once every other month. I'm not a big movie-goer, but I like to take my daughter every once in a while.
* How do you prefer to book movie theater seats?
	* I rarely book them ahead of time unless it's a popular movie my daughter has wanted to see for some time. Otherwise we just buy the tickets at movie theater at the time of the movie.
* What is the best and worst part about booking movie theater seats online?
	* Best: I can be assured we have a spot at the movie. We've sometimes had to watch something else or reschedule when the theater's full and I haven't booked tickets in advance.
	* Worst: I have a busy and constantly changing schedule, the worst part about booking seats online is when they're non-refundable and can't be changed.
* If you could change one thing about the service you used for your most recent seat-booking experience, what would it be?
	* I would like it if you could reserve seats for some time without buying tickets. Or order the tickets on the website, but you only have to pay for them once you arrive at the movie.
* What information would you expect in an app for booking seats at a movie theater?
	* Trailer, movie information, price and available seats.
* Which medium do you prefer to use when booking movie theater seats, and why?
	* I like to use my phone, as it's pretty easy to use on most of the local theaters' websites.
  

# Groups
## Group 1
Young students who enjoy going to the movie theater, but have limited time and money.
* Tend to be very tech literate.
* Tend to be in their early 20s.
* Has siblings.
* Prefer to book movie theater seats online.
* Goes to the movie theater 2 - 5 times a month.
* Ambitious about their education and career.
* Varying interests.

## Group 2
Working adults who mostly go the movie theater for the social aspect.
* Tend to be between 35 and 45 years old.
* Have additional obligations, interests, or challenges that make it difficult for them to book movie tickets far in advance.
* Open to buying movie tickets in person.
* Often more suspicious of websites asking for personal information.
* Ambitious about their education and career.
* Would like a booking service that has refundable/changeable tickets.