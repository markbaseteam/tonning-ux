![[Prompt.png]]

Design a seat reservation app for a movie theater.