## Describe your product's features and benefits
* Browse upcoming movies
* View information about movies
* Built-in translation
* One standard app for multiple theaters
* Change tickets, or trade in for in-app credit
* Reserve seats without account or personal info
* Easy overview of all available seats
* Subscription option for frequent movie-goers
* Movie theater rating

## Explain the value of the product
* Built-in translation
* One standard app for multiple theaters
* Change tickets, or trade in for in-app credit
* Reserve seats without account or personal info
* Easy overview of all available seats

## Connect these features and benefits with the needs of your users
### Lukas
* One standard app for multiple theaters

### Malou
* Reserve seats without account or personal info