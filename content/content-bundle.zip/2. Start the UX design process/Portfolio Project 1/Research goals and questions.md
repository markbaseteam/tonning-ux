#research 

## Goals

* I want to learn about the pain points users experience with existing seat booking services.
* I want to identify common user behaviors and experiences with tasks that my product is trying to address.
* I want to understand why some users prefer to book seats in person instead of online.


## Target audience

* Age 18 - 64
* Has a smartphone
* Lives in metropolitan or suburban areas
* Frequently goes to the movie theater
* Include participants of different genders
- Include participants with disabilities


## Questions

* How often do you book movie theater seats?
* How do you prefer to book movie theater seats?
* What is the best and worst part about booking movie theater seats online?
* If you could change one thing about the service you used for your most recent seat-booking experience, what would it be?
* What information would you expect in an app for booking seats at a movie theater?
* Which medium do you prefer to use when booking movie theater seats, and why?