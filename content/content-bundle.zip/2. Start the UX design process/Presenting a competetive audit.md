After researching direct and indirect competitors, and compiling those findings into a spreadsheet, the next step is sharing your insights with your team or client. 

You can present your competitive audit as a written report or a slideshow presentation using software like Google Slides, Microsoft PowerPoint, or Apple’s Keynote. This course will teach you how to present your audit findings as a written report, but in the workplace you can choose from many different formats to demonstrate what you’ve learned to stakeholders. In this reading, you’ll learn about some best practices for creating a slideshow presentation of your competitive audit findings. 

Both written reports and slideshow presentations have their advantages. Slideshows are dynamic and visually engaging, but require more time and effort to create and rehearse. Written reports are more concise and less time-consuming to create. They’re an efficient way to communicate insights quickly when your audience doesn’t have a lot of time. 

Later in the course, you’ll prepare to present a competitive audit for your portfolio project. You’ll learn more about written reports when you get there. Right now, let's explore some best practices for  presenting competitive audit findings as a slideshow presentation. Ready to learn more? Here we go!

## Tips for your slides and presentation structure

Every good presentation needs an introduction, so you’ll want to begin by laying out the goals of your competitive audit. It’s also a good idea to outline your research questions, methodology, and  the features or characteristics you compared across competitors. Summarizing the purpose of your presentation makes it clear exactly what you're trying to learn about the competition. Note that the example introductory slide below includes sections for an objective, research questions, and procedures.

![Slide that shows goals & methods, broken into Objective, Research Questions, and Procedure.](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/VyqLxsMsTzSqi8bDLD80hQ_24e3c2a8df5444ba89ce8d5384d58f6f_Screen-Shot-2020-12-11-at-7.47.10-AM.png?expiry=1673913600000&hmac=3p0T4IlfFeabHenTL2fnnQNLfMll1igIZEk3jJAXnbM)

Slide that shows goals and methods, broken into Objective, Research Questions, and Procedure. Objective: Burger Garden says their clients have lost interest in their product. We audited industry competitors to understand how the BG app compares. Research Questions: Are they attracting the right audience that they say they are speaking to? How does their app look and feel? Does the design complement the product? Will the user get confused as they navigate through the app? Procedure: We reviewed these aspects of each restaurant and their app or website design: Audience, First Thoughts, User Interaction, Visual Design, and Content.

To organize your information for your audience, begin each section of your presentation with a slide that identifies the section’s topic (similar to a chapter title in a book). Stick to simple, clear visuals, like the bold text and solid background of the slide below:

![Orange square, with the word "Navigation" typed in white in the center.](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/O4dhCUjoSsaHYQlI6HrGkA_f1f7e3c1dc624fa9af1694e0e7ebf376_Screen-Shot-2020-12-11-at-7.39.02-AM.png?expiry=1673913600000&hmac=qfnb4Lqo60na1Sg-GAIR4Kx-Mumzuzrf-hA5Prt7MD0)

Next, summarize what you learned about your competitors’ products, and how they compare to yours. Be sure to point out where your product excels, as well as areas that need improvement.

As you organize your presentation, think about the most effective ways to present your insights. Keep the overall design as simple and clean as possible. Avoiding cluttered and confusing imagery makes it easier for your audience to follow along and focus on the important information. Note how the example slide below outlines  the most important information and expands on it  in the section to the left:

![Visual presentation of competitive audit findings for Burger Garden located in Kansas City, Missouri.](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/RGh4kVpkSByoeJFaZFgcAg_90bab153eac446cd987666211f12af57_Screen-Shot-2020-12-11-at-7.44.51-AM.png?expiry=1673913600000&hmac=ELzGZBAGnH-CNrtV5HiARjr-8fd3uO02CoMGSjf4PUQ)

Visual presentation of competitive audit findings for Burger Garden located in Kansas City, Missouri. On the left of the presentation slide, text shows the cost of burgers (around $10 each), the business size (small), the audience (millennials), the unique value prop (large variety of burgers and toppings), and the initial findings (clear branding identified in screenshot A, content ton is inconsistent in screenshot B). On the right side of the slides are two screenshots. Screenshot A shows the company name is clearly displayed at the top of their website. Screenshot B shows text on the website that reads "Each ingredient implemented into our burgers is of the highest grade and viscosity, assembled with diligence and care for your family unit."

Finally, conclude your presentation with  a summary of key points and takeaways. As you learned earlier, competitive audits can compare up to 10 companies. That’s a lot of information for your audience to take in! A summary can refresh their memories by recapping the most important information. 

## Presenting data effectively

The way you present your data can influence how your audience interprets it. Keep in mind that different types of data lend themselves to different formats. For example, if your presentation has a lot of numbers or quantitative data, a chart or graph can help your audience grasp how the numbers compare to one another. To demonstrate a specific function or issue with a competitor’s product, consider including a screen recording in your presentation. Finally, it can be helpful to include a rubric that explains the grading system you used in your audit. For example, the rubric system used in the example audit graded the burger restaurants from “needs work” to “outstanding.” Using that rubric, each restaurant was rated on a scale of one to four in each category to create a final rating.

## Delivering a strong presentation

Knowing what  to include in your presentation is only part of the process. As you prepare to present your findings, keep these tips for effective presentations in mind:

-   **Get feedback from your team.** Share your report or slides with a trusted teammate ahead of time to get their take on how the information flows. 
-   **Limit the amount of text on your slides.** Your slides should include just enough information to draw attention to important points. Save the details for your speech. 
-   **Stick to the highlights.** A presentation to your team or client should only focus on the highlights of your audit. If you want to get into more detail, add them to the appendix of your presentation or create a written report. 
-   **Use notes.** An outline or note cards can help you stay focused, on topic, and on time. 
-   **Practice ahead of time.** Do a few trial runs before the big day to get comfortable with the content and pace of your presentation.
-   **Use relevant graphics.** Make sure any images and graphics relate directly to the topic of your presentation. Choose images and graphics carefully to ensure they enhance clarity.
-   **Keep your biases in check.** Be aware of your own design biases and try to prevent them from clouding your judgment during the presentation.
-   **Be able to defend your conclusions.** Make sure you have evidence to back up your conclusions. Use actual data and specific examples whenever possible. 

Presenting your research can seem intimidating, but remember that you are representing your users! Competitive audits give you, your team, and your clients knowledge that will help create well-rounded product designs that work. To ease your presentation jitters, check out  this article from Forbes for expert tips on connecting with your audience:  [20 World-Class Presentation Experts Share Their Top Tips](https://www.forbes.com/sites/markfidelman/2014/08/15/20-world-class-presentation-experts-share-their-top-tips/?sh=2920b075c40d).