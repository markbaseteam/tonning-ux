## Creating an empathy map

Now that you’ve had a chance to review Makayla’s interview transcript, let’s break down the steps for creating an empathy map. As a reminder, here’s what an empathy map includes: 

![[Empathy map.png]]

You can fill out this empathy map with a handful of steps.

**Step 1: Add the user’s name.** Include the name of the person interviewed in your empathy map. Having a name attached to it will help if you ever need to look back at the original transcript or research, and it’ll distinguish this map from other maps you create.

**Step 2: The “SAYS” square.** Use verbatim quotes from the interview. In other words, write down exactly what the person said; don’t summarize it in your own words. If you summarize a quote, you might accidentally interpret the user’s meaning incorrectly. It’s also helpful to try to capture themes in the interview that relate to the product you’re researching. For example, if the user restates the same problem several times during the interview, then it’s probably a major pain point. Pay special attention to challenges your user states, and record any desired benefits or expectations they mention. 

**Step 3: The “THINKS” square.** Here, you can summarize the thoughts expressed by the user. Add feelings the user conveyed through body language, tone, or other noticeable indicators, even if they didn’t verbally express them to you. You can make inferences for some of these feelings, but you have to be careful not to make assumptions about the user. For example, Makayla expressed concern about her neighbor’s teenage son and mentioned his age and qualifications. An assumption is that Makayla wants an adult dog walker. An inference is that she wants a dog walker with a car and a driver's license who can take the dog to the emergency vet. You can always ask your user for clarification on their body language if you find any contradictions.  

**Step 4: The “DOES” square.** Makayla gave us quite a bit of detail on steps and actions she takes to overcome the dog-walking challenges she faces. All those actions can go in the “DOES” square.

**Step 5: The “FEELS” square.** List the feelings the user expresses. The notes you include may overlap with some of what you listed in the “THINKS” square. That’s okay! This process is meant to be a thorough documentation of your observations. If you’re the person performing the interview, you might notice signs of feelings like anger, frustration, excitement, and others. If the user doesn’t explicitly mention any feelings during the interview, you can probe for feelings with the question: “How does this make you feel?”


## Types of empathy maps

It's important to understand that there are two types of empathy maps: **one-user empathy maps** and **aggregated empathy maps** (also known as "multiple-user empathy maps"). One-user empathy maps are created by taking the data from one user's interview and turning it into an empathy map, like the example earlier in this reading. This approach helps designers distill a single user's thoughts, feelings, and traits into a format that's easier to gather data from.

The other kind of empathy map, an aggregated empathy map, represents a group of users who share similar thoughts, opinions, or qualities. Aggregated empathy maps are created by creating multiple one-user empathy maps, then combining the maps where users expressed similar things into a new empathy map. This helps designers identify segments, or groups of people with similar tendencies, who will use the product. The insights in aggregated empathy maps allow designers to identify themes, which helps them better empathize with the groups they are designing for. To learn more about the different kinds of empathy maps, check out this article on [empathy mapping](https://www.nngroup.com/articles/empathy-mapping/) from the Nielsen Norman Group.