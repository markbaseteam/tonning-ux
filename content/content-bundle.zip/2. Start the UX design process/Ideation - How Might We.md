Brainstorming possible solutions to your design problems is an opportunity to get creative and have some fun! The “How might we” exercise is one of the most common ways to approach the ideation process.

**“How might we” (HMW)** is a design thinking activity used to translate problems into opportunities for design. HMW gets your creativity flowing and encourages you to think about the problem from different perspectives. This new vantage point helps you create a wide variety of solutions to the user problem you’re trying to address. During a HMW exercise, you’d create a list of questions that start with “How might we” and use those to spark ideas for solutions.

You'll learn about two different methods for design ideation in this lesson: HMW and Crazy Eights. These are only a few of the many different ways you can ideate solutions to problems. Completing a HMW activity isn't required for this course, but it might be helpful to start sketching some of your ideas to get a feel for the process!

## Frame HMW questions

To create good HMW questions, you need a well-defined problem statement. From there, you can reframe this problem statement into questions that will help you come up with ideas to solve the problem.

Consider this problem that a user, Darren, faces: Darren is a concert goer who needs to keep track of their concert ticket because they need the ticket when they go through security. 

Let’s revisit those useful tips from the Stanford University design school that you learned about in the video. These tips will help you reframe the problem from different angles.

![](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/YdO5X-W5T4WTuV_lue-Fvw_b2ce5b7f51044188a14fbaed23b97df1_Graphic-updates-12-.png?expiry=1673913600000&hmac=HQD6JsDcpHRYdcAN07OgTcJ5IsYMu12m1ymHWWe7D6E)

Think of how you might use any positives in the problem as a solution. 

_How might we make keeping track of tickets a fun competition among friends?_ 

![](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/7FHZBjMBTH2R2QYzAYx9KA_ab9dc58a812c4aafbdec44b5784c91f1_Graphic-updates-11-.png?expiry=1673913600000&hmac=C-LdnzAMefV7WQT8Y_t-CESZ_aTnD0csRZHm6BbUg8I)

Think of how you’d solve the opposite of the problem you’ve outlined. 

_How might we create a way to lose tickets?_

![](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/pYuFHz-SRBaLhR8_kvQWPw_06100305278d41dea290f75972a6faf1_Graphic-updates-10-.png?expiry=1673913600000&hmac=MfksPoLhBhhQFvskIp-UfFGE0sDvp3a7MdW8-vJn1qQ)

Think of ways to completely change the process. 

_How might we make a non-paper concert ticket?_ 

![](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/npcZ1xdrQuCXGdcXa4LgjQ_cfe5e1095094437f85a67df2811fc9f1_Graphic-updates-19-.png?expiry=1673913600000&hmac=xkgteGFrAe1a-OwHMaRkzp-xtMC_ygX6Ll-tEnN8uuY)

This is especially helpful for long, complex problems. 

_How might we keep the customer’s ticket from getting lost? How might we make a lost ticket easier for the security team to handle?_

![](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/RXclCBt-SZ63JQgbfrmewg_4655fa564046478a8955d0ac91003df1_Graphic-updates-18-.png?expiry=1673913600000&hmac=2-EhWNmgNbMKAELPdKNmqkTMNY2rrXn8bv-1QxUb3CI)

Think of how to remove the negative part of the problem entirely. 

_How might we make a way for concert goers to enter a venue without needing a ticket?_

![](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/u671pLH9Sgmu9aSx_WoJtw_8b9fd6128e51479592d1270578f53ef1_Graphic-updates-17-.png?expiry=1673913600000&hmac=p4TKb-Bc61clJzMlgMzRTgBw_9-7vBdoabofxVMK9EI)

Take any negative adjectives and try to turn them into positives. 

_How might we make the entry to a concert venue less stressful for ticket holders?_

![](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/d62UGySmR9OtlBskptfT2g_f9fe64f8c61540c6964c76a84c4cd8f1_Graphic-updates-16-.png?expiry=1673913600000&hmac=lf6MEa6NX1L_65-gmSTfWt8GqbAUB4fIARhKiQk3cG8)

Remove or change any processes that you assume have to be in place.

_How might we remove the security check process at a concert?_

![](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/jBkibIukQtmZImyLpMLZ7A_6baf50c36b2f47a68fbb96d0354685f1_Graphic-updates-9-.png?expiry=1673913600000&hmac=mECUcvdkyo5RNgJDaVQij1NmnBxxe0TZi2aoNlyHIRA)

Think of ways to compare this user experience to another experience.  

_How might we make going through security like playing a video game?_

![](https://d3c33hcgiwev3.cloudfront.net/imageAssetProxy.v1/llDz7B91S2aQ8-wfdbtm7g_3f72d9a7e8274d01a0436999accb5ef1_Graphic-updates-7-.png?expiry=1673913600000&hmac=_ZxNx2RE3N_4950aqhBxi7F1kAZljKqfvrlBgw0ncO8)

Think of how the problem might be solved by a resource that isn’t mentioned in the problem statement. 

_How might facial recognition software help manage concert entry?_

If you want more inspiration, check out Stanford’s [one-pager on “how might we” questions](https://static1.squarespace.com/static/57c6b79629687fde090a0fdd/t/589cc8b8d2b85721b37d3efe/1486670008488/HMW-Worksheet.pdf). 

## Best practices for thinking of HMWs

Coming up with good HMWs takes a little practice, but you’ll get the hang of it in no time! Here are some best practices to keep in mind:

-   **Be broad**. A good HMW should allow for multiple solutions. For example, one of the earlier questions, _How might we make keeping track of tickets fun and competitive?,_ can be answered in countless ways.
-   **But don’t be too broad**. You want your HMWs to be comprehensive, but narrow enough to keep your solutions focused. An example of a HMW question that is too broad is: _How might we make ticketing better?_ This HMW doesn’t provide clear enough guidance to come up with ideas for solutions. 
-   **Make multiple drafts**. It’s okay to change your HMW questions after you’ve written them. If you find that your HMW doesn’t help you think of any useful solutions, change it up!
-   **Be creative**. HMWs are meant to be imaginative and even fun. You can use the list of tips from Stanford above to think of new, creative ways to frame your questions.
-   **Write as many HMWs as you can**. The more HMWs you have, the more solutions you can come up with. If you can make more than one question out of the frameworks you’ve learned, then go for it!