#research 

## **Determine research goals**

You want to ensure that the interviews you conduct are worthwhile, both for you and for the participants. To make the most of your time together, you need to determine clear goals for the interview. As a UX designer, what do you want to learn from the interviews? Are there certain user problems or pain points that you need to empathize with?

Here are some examples of common research goals when it comes to empathizing with users:

- I want to understand the processes and emotions that people experience around the problem my product is trying to solve.
- I want to identify common user behaviors and experiences with tasks that my product is trying to address.
- I want to understand user needs and frustrations as they relate to the product I’m designing.

## **Write interview questions**

Keeping the goals of the interview in mind, you can write your interview questions. The more aligned the interview questions are with your goals, the more useful the data you obtain will be.

There are a few best practices to keep in mind when writing interview questions:

-   **Ask open-ended questions.** Open-ended questions allow the person being interviewed to answer freely, instead of with a simple “yes” or “no.” For example, if you’re designing an app to help people find dog walkers, you should ask “Could you describe your experience with finding and scheduling dog walkers?” instead of “Have you ever used an app to find a dog walker?” Keep in mind that the questions you ask during interviews should not lead or pressure participants towards a desired response; instead, asking open-ended questions lets participants share their true thoughts and perspectives.
-   **Keep questions short and simple.** It should be easy for interview participants to understand what you’re asking.
-   **Ask follow-up questions.** During the empathize phase of the design process, interviews should be conversational, so encouraging participants to elaborate is a best practice. After a participant answers an interview question, try asking them “Why?” or use the phrase, “Tell me more about that” to keep the conversation flowing.

Research is an essential part of the UX design process and empathizing with users. Taking time to outline the goals for your research will help ensure the feedback you obtain is valuable.